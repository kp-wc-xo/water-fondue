// Public snapshot only; credentials never enter the site directory.
let snapshot = null;
const el = id => document.getElementById(id);
const format = value => value && Number.isFinite(Date.parse(value)) ? new Date(value).toLocaleString('th-TH', {timeZone:'Asia/Bangkok'}) : 'ไม่มี';
function render() {
  if (!snapshot) return;
  const data=snapshot, staleLimit=data.stale_minutes ?? 120, futureLimit=data.max_future_minutes ?? 15;
  const age= (Date.now()-Date.parse(data.ingestion?.at))/60000;
  el('pipeline').textContent= !Number.isFinite(age) || age>staleLimit || age < -futureLimit ? 'ตรวจสอบระบบดึงข้อมูล: เวลาล่าสุดเก่าหรือผิดปกติ' : 'ระบบดึงข้อมูลสำเร็จภายในช่วงที่กำหนด';
  el('mode').textContent=data.profile==='test' ? 'ข้อมูลตัวอย่างสำหรับทดสอบ' : 'ข้อมูลจาก ThaiWater';
  el('status').textContent=`ดึงสำเร็จ: ${format(data.ingestion?.at)} | ส่งออก: ${format(data.generated_at)}`;
  const body=el('rows'); body.replaceChildren();
  const query=el('search').value.trim().toLowerCase();
  let shown=0;
  for (const row of data.rows) {
    if(query && !`${row.name} ${row.station_key}`.toLowerCase().includes(query)) continue;
    const age=(Date.now()-Date.parse(row.observed_at))/60000;
    const stale=!Number.isFinite(age)||age>staleLimit||age < -futureLimit;
    const missing=row.level_msl===null || row.level_msl===undefined;
    const tr=document.createElement('tr');
    const label=stale ? 'ข้อมูลเก่าหรือเวลาผิดปกติ' : missing ? 'ไม่มีค่าระดับน้ำ' : 'อยู่ในช่วงความสดที่กำหนด';
    for(const value of [row.name||row.station_key,row.level_msl??'ไม่มีค่า',format(row.observed_at),label]) {
      const td=document.createElement('td'); td.textContent=value; tr.append(td);
    }
    if(stale||missing) tr.className='stale'; body.append(tr); shown++;
  }
  el('count').textContent=`แสดง ${shown} จาก ${data.rows.length} สถานี`;
}
async function refresh() {
  try {
    const response=await fetch('data.json',{cache:'no-store'});
    if(!response.ok) throw new Error('ยังไม่มีข้อมูลส่งออก โปรดตรวจ workflow');
    const data=await response.json();
    if(!Array.isArray(data.rows)) throw new Error('รูปแบบข้อมูลไม่ถูกต้อง');
    snapshot=data; el('error').textContent=''; render();
  } catch(error) {el('error').textContent='โหลดไม่สำเร็จ: '+error.message+' ข้อมูลที่ค้างอยู่ด้านล่างอาจไม่ใช่รอบล่าสุด'; render();}
}
el('refresh').addEventListener('click',refresh);
el('search').addEventListener('input',render);
setInterval(refresh,60000); setInterval(render,30000); refresh();
