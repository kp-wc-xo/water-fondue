# Water Fondue 2.1

เริ่มที่ docs/01_SETUP_TH.md หรือคู่มือ Word ใน docs/ อ่านตามลำดับจนเปิดเว็บและ scheduled run สำเร็จ

Architecture: ThaiWater → GitHub Actions Python → Supabase PostgreSQL + private gzip raw → public snapshot → GitHub Pages.

## Local quick start
```powershell
py -3 -m unittest discover -s tests -v
py -3 run.py collect --profile test --input tests/fixtures/sample.json
py -3 run.py export --profile test
py -3 -m http.server 8000 --directory site
```
Open http://localhost:8000. Stop with Ctrl+C.

Production needs SUPABASE_URL and SUPABASE_SECRET_KEY set as GitHub repository secrets, RUN_ENABLED=true to enable schedules, a private water-raw bucket, and sql/supabase.sql applied to a fresh Supabase project. Pages Source must be GitHub Actions. Do not commit credentials or data/. Run workflows manually first.

## Scope
Latest water-level table, station search, freshness indicators, history storage, raw cleanup, manual backup and local restore. Rainfall, historical backfill, maps, history charts and forecasts are not implemented. Optional LINE module is disabled.

Offline tests and live ThaiWater extraction were exercised. Supabase SQL/API, GitHub deployment and LINE delivery were not exercised against a real account in this delivery; follow the acceptance checks in the guide. Use a new directory to avoid mixing earlier test databases.

## Changes from 2.0
- Recognize real ThaiWater tele_station_name.
- Support Supabase sb_secret_ keys using the apikey header; legacy service_role environment fallback remains for old installations.
- Raw archives limited to configured province, preserving original fields.
- Source adapter separated for future extensions.
- Website freshness follows exported configuration, refreshes automatically, and labels test snapshots.
- New step-by-step Thai Word guide, flow diagram, verification SQL and compatibility tests.

The database filename and raw wf2 namespace remain unchanged for v2 compatibility. Code has no third-party Python runtime dependencies. Data files and secrets are excluded from this distribution.
