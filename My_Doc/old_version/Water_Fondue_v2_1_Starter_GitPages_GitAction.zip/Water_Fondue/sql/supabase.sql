-- Run once in a NEW Supabase project. Do not apply over v1 tables.
begin;
create table if not exists public.stations (
 station_key text primary key, name text, province_code text, district_code text);
create table if not exists public.observations (
 station_key text not null references public.stations(station_key), observed_at timestamptz not null,
 level_msl double precision, level_m double precision, situation double precision,
 primary key(station_key,observed_at));
create table if not exists public.state(key text primary key,value jsonb not null);
alter table public.stations enable row level security;
alter table public.observations enable row level security;
alter table public.state enable row level security;
revoke all on public.stations,public.observations,public.state from anon,authenticated;
grant all on public.stations,public.observations,public.state to service_role;
create or replace view public.latest_water with (security_invoker=true) as
 select distinct on (o.station_key) o.*,s.name,s.province_code
 from public.observations o join public.stations s using(station_key)
 order by o.station_key,o.observed_at desc;
revoke all on public.latest_water from anon,authenticated;
grant select on public.latest_water to service_role;
create or replace function public.ingest_water(p_stations jsonb,p_observations jsonb)
returns void language plpgsql security invoker set search_path=public as $$
begin
 insert into stations select * from jsonb_to_recordset(p_stations)
 as x(station_key text,name text,province_code text,district_code text)
 on conflict(station_key) do update set name=excluded.name,province_code=excluded.province_code,
 district_code=excluded.district_code;
 insert into observations select * from jsonb_to_recordset(p_observations)
 as x(station_key text,observed_at timestamptz,level_msl double precision,level_m double precision,situation double precision)
 on conflict(station_key,observed_at) do update set level_msl=excluded.level_msl,
 level_m=excluded.level_m,situation=excluded.situation;
end $$;
revoke all on function public.ingest_water(jsonb,jsonb) from public,anon,authenticated;
grant execute on function public.ingest_water(jsonb,jsonb) to service_role;
commit;
