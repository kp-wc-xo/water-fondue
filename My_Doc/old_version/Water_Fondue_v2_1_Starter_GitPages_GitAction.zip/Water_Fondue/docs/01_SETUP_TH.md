# คู่มือติดตั้ง Water Fondue ตั้งแต่เครื่องส่วนตัวถึงเว็บ

Water Fondue 2.1 • คู่มือสำหรับ Windows และ VS Code • ตรวจเอกสารบริการวันที่ 1 ตุลาคม 2026

คู่มือนี้พาคุณติดตั้งระบบเก็บระดับน้ำสุโขทัยจาก ThaiWater ลงฐานข้อมูล Supabase และเปิดดูผ่านเว็บ GitHub Pages โดย GitHub Actions เรียก Python ตามตารางเวลา เมื่อทำครบจะปิดคอมพิวเตอร์ได้ เพราะงานเก็บข้อมูลรันบน Cloud

ใช้ไฟล์ ZIP รุ่น 2.1 คู่กับคู่มือนี้ แตกในโฟลเดอร์ใหม่ ไม่ทับรุ่นเดิม ข้อมูลตัวอย่างใช้ทดสอบในเครื่อง ส่วนการขึ้น Cloud ใช้ข้อมูลจริงจาก API เท่านั้น

## 1 ภาพรวมและสิ่งที่จะได้

![High level workflow](Water_Fondue_High_Level_Flow.png)

1. GitHub Actions เรียก run.py ตาม cron เป้าหมายทุก 15 นาที หรือกด Run workflow ด้วยมือ
2. Python เรียก ThaiWater แล้วกรองจังหวัด 64 สุโขทัย ตรวจรหัสสถานี เวลา และแปลงตัวเลข
3. เก็บ JSON ต้นทางเฉพาะจังหวัดเป็น gzip ใน bucket ส่วนตัว และ upsert ค่าตรวจวัดลง PostgreSQL
4. อ่านค่าล่าสุดจากฐานข้อมูล ส่งออก site/data.json แล้วเผยแพร่ site/ ขึ้น GitHub Pages
5. ผู้ใช้เปิด URL บนมือถือหรือคอมพิวเตอร์ เว็บอ่าน snapshot สาธารณะโดยไม่มีรหัสฐานข้อมูล

ข้อมูลประวัติเริ่มสะสมเมื่อเปิดระบบ ไม่ได้ดึงประวัติย้อนหลังทั้งหมดจาก ThaiWater เว็บรุ่นนี้แสดงตารางล่าสุด ค้นหาสถานี และบอกความสดของข้อมูล ยังไม่มีกราฟย้อนหลัง แผนที่ หรือพยากรณ์ 24–48 ชั่วโมง


## 2 เตรียมบัญชีและโปรแกรม

ทำตามลำดับนี้ หากมีโปรแกรมอยู่แล้วให้ตรวจเวอร์ชันแล้วข้ามการติดตั้ง

1. สมัคร GitHub ที่ https://github.com ด้วยอีเมลของคุณ ยืนยันอีเมลให้เสร็จ
2. สมัคร Supabase ที่ https://supabase.com/dashboard เลือกองค์กร Free ไม่เลือก Pro หรือบริการเสริม
3. ติดตั้ง Python 3.12 จาก https://www.python.org/downloads/ บน Windows ให้เลือก Add Python to PATH ถ้ามีตัวเลือกนี้
4. ติดตั้ง VS Code จาก https://code.visualstudio.com/ และ Git จาก https://git-scm.com/downloads/win แล้วเปิด VS Code ใหม่
5. แตก Water_Fondue_v2_1_Starter.zip จะได้โฟลเดอร์ Water_Fondue ย้ายไป C:\Projects\Water_Fondue
6. ใน VS Code เลือก File > Open Folder > C:\Projects\Water_Fondue ต้องเห็น run.py, config.json, site, sql และ water_fondue
7. เลือก Terminal > New Terminal ใช้ PowerShell แล้วตรวจโปรแกรม

```powershell
py -3 --version
git --version
```

ผลที่ต้องได้คือ Python 3.11 ขึ้นไป และ git version ตามที่ติดตั้ง ถ้า py ใช้ไม่ได้แต่ python ใช้ได้ ให้ใช้ python แทน py -3 ในทุกคำสั่งของคู่มือ

โค้ดใช้ standard library ของ Python ไม่ต้อง pip install แพ็กเกจเพิ่ม หากโฟลเดอร์ .github ไม่แสดง ให้ตรวจใน File Explorer ว่าแตก ZIP ครบ โฟลเดอร์นี้เก็บ workflow สำคัญ

บริการที่ใช้และข้อจำกัด

| บริการ | ใช้ทำอะไร | เงื่อนไขที่ต้องรู้ |
|---|---|---|
| GitHub Actions | เรียก Python ตามเวลา | standard runner ใน public repo ใช้ฟรี ตารางเวลาอาจช้า |
| GitHub Pages | เปิดเว็บและ snapshot | GitHub Free ใช้ public repository ตามแนวทางนี้ |
| Supabase Free | PostgreSQL และ raw storage | DB 500 MB และ file storage 1 GB มีโควตา egress |
| เครื่องคุณ | ทดลองและเก็บ backup | ใช้ SQLite แยกจากฐานข้อมูล Cloud |

Supabase Free อาจพักโปรเจกต์หลังไม่มีการใช้งาน 1 สัปดาห์ และไม่มี automatic backup รวมในแผนฟรี ตรวจหน้าราคาอีกครั้งตอนสมัคร อย่าประเมินว่าเก็บได้ไม่จำกัดเพียงเพราะไม่มีค่ารายเดือน


## 3 ทดสอบในเครื่องด้วยข้อมูลตัวอย่าง

เปิด Terminal ที่โฟลเดอร์ซึ่งมี run.py แล้วรันทีละบรรทัด รอแต่ละบรรทัดจบก่อน

```powershell
py -3 -m unittest discover -s tests -v
py -3 run.py collect --profile test --input tests/fixtures/sample.json --dry-run
py -3 run.py collect --profile test --input tests/fixtures/sample.json
py -3 run.py export --profile test
py -3 -m http.server 8000 --directory site
```

ผลที่ต้องได้

1. tests จบด้วย OK และผ่าน 16 tests
2. dry-run แสดง stations 1, observations 1 และไม่เขียนฐานข้อมูล
3. collect สร้าง data/test/water_fondue_v2.sqlite พร้อมไฟล์ raw gzip
4. export สร้าง site/data.json
5. เปิด http://localhost:8000 ใน browser จะเห็นป้ายข้อมูลตัวอย่างและหนึ่งสถานี

ข้อมูลตัวอย่างมีวันที่คงที่ จึงแสดงข้อมูลเก่าหรือเวลาผิดปกติได้ ถือว่าทำงานถูกต้อง ปุ่มโหลดใหม่อ่าน snapshot ที่ export ไว้ ไม่ได้เรียก ThaiWater โดยตรง

กด Ctrl+C ใน Terminal เพื่อหยุดเว็บ หากต้องการดู SQLite ให้เปิด DBeaver > New Database Connection > SQLite > เลือกไฟล์ใน data/test แล้วเปิด Tables

ลองรัน collect ด้วยไฟล์เดิมอีกครั้ง จำนวน observations ต้องยังเป็นหนึ่ง เพราะใช้คู่ station_key และ observed_at ป้องกันข้อมูลซ้ำ ข้อมูลตัวอย่างจะไม่ถูกส่งไป Cloud

## 4 ทดสอบดึงข้อมูลจริงจาก ThaiWater

เปิด config.json ตรวจ province เป็น "64" และ line_enabled เป็น false ไม่ต้องรัน master จังหวัดจาก GitHub เพราะโค้ดอ่าน geocode จาก API โดยตรง

```powershell
py -3 run.py collect --profile local --dry-run
py -3 run.py collect --profile local
py -3 run.py export --profile local
py -3 -m http.server 8000 --directory site
```

เปิดเว็บเดิมและกดโหลดใหม่ ตอนทดสอบชุดส่งมอบพบ 18 สถานีในสุโขทัย แต่จำนวนจริงเปลี่ยนได้ ให้ใช้เงื่อนไข observations มากกว่า 0 และตรวจชื่อ เวลา และค่ากับ ThaiWater

ถ้าได้ 0 observations หรือ error ให้แก้ที่ขั้นนี้ก่อนขึ้น Cloud เช่น internet, endpoint, schema หรือ province หากมี rejected ให้ตรวจ record ต้นทาง raw การดึงทุก 15 นาทีไม่ได้บังคับให้เซนเซอร์อัปเดตทุก 15 นาที


## 5 สร้างฐานข้อมูล Supabase

1. เข้า Supabase Dashboard > New project เลือกองค์กร Free ตั้งชื่อ water-fondue
2. ตั้ง database password ที่แข็งแรงและเก็บไว้ เลือก region ใกล้ผู้ใช้งาน เช่น Singapore ถ้ามี แล้วรอ project พร้อม
3. ไป SQL Editor > New query เปิดไฟล์ sql/supabase.sql ใน VS Code คัดลอกทั้งหมด วางใน editor แล้วกด Run
4. ไป Table Editor ตรวจว่ามี stations, observations และ state ส่วน latest_water เป็น view ไม่ใช่ตารางเก็บประวัติอีกชุด
5. ไป Storage > New bucket ตั้งชื่อ water-raw ให้ตรงทุกตัวอักษร เลือก Private หรือปิด Public แล้วสร้าง bucket
6. เปิด Connect หรือ Settings > API Keys จด Project URL เช่น https://PROJECT_REF.supabase.co
7. ใน API Keys สร้างหรือคัดลอก backend Secret Key ที่ขึ้นต้น sb_secret_ เก็บเฉพาะใน password manager และ GitHub Secret ตามขั้นถัดไป

อย่าใช้ database password, anon key หรือ publishable key แทน Secret Key ของ collector หน้าเว็บไม่ต้องใช้ key ใด ๆ และไม่ต้องเพิ่ม public read policy ให้ตารางหรือ bucket

ชุด SQL นี้ใช้กับ project ใหม่ที่ยังไม่มีตารางชื่อเดียวกัน ถ้ามีฐานข้อมูลรุ่นเดิมอยู่ ให้สร้าง project แยกเพื่อทดลองก่อน ไม่รัน SQL ทับ schema ที่ต่างกัน หากเคยใช้ v2 schema เดิมที่ตรงกัน ให้สำรองข้อมูลก่อนเปลี่ยนโค้ด

เช็กผลใน SQL Editor

```sql
select count(*) from public.stations;
select count(*) from public.observations;
```

ก่อนรัน collector จำนวน 0 เป็นเรื่องปกติ ตรวจความปลอดภัยเพิ่มเติมได้ด้วย sql/verify.sql ค่า anon_can_read และ anon_can_insert ต้องเป็น false และ relrowsecurity ของสามตารางเป็น true

เวลาที่เก็บใน observed_at เป็น UTC ชนิด timestamptz เวลาบนเว็บแปลงเป็น Asia/Bangkok ไม่ต้องแก้ค่าใน DB เพิ่มอีก 7 ชั่วโมง


## 6 ใส่โค้ดลง GitHub

แนวทางนี้ใช้ public repository เพื่อใช้ Pages และ standard Actions runner แบบฟรี โค้ดกับ snapshot ระดับน้ำจะเผยแพร่สาธารณะ ส่วนฐานข้อมูล raw และ secrets ไม่อยู่ใน repository

1. ใน GitHub กดเครื่องหมาย + > New repository ตั้งชื่อ water-fondue เลือก Public
2. ไม่เลือก Add README, .gitignore หรือ license ในขั้นสร้าง เพื่อเริ่มด้วย repository ว่าง แล้วกด Create repository
3. กลับ VS Code เปิด Terminal ในโฟลเดอร์ที่มี run.py ตรวจ .gitignore ว่ามี data/, .env, *.sqlite* และ site/data.json
4. ตั้งชื่อและอีเมล Git ด้วยข้อมูลของคุณ จากนั้นรันตามนี้ เปลี่ยน YOUR_USERNAME เป็นชื่อบัญชีจริง

```powershell
git config --global user.name "YOUR_NAME"
git config --global user.email "YOUR_EMAIL"
git init
git add .
git status
git commit -m "Add Water Fondue 2.1"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/water-fondue.git
git push -u origin main
```

ก่อน git commit อ่าน git status ต้องไม่มี data/, .env, SQLite หรือ credential จริง ระบบจะไม่ upload site/data.json ที่สร้างจาก local เพราะ workflow จะสร้างใหม่จาก Cloud

หาก Git เปิด browser ให้ sign in ตามขั้นตอน Git Credential Manager ไม่ใส่ token ลงใน URL หากขึ้น remote origin already exists ให้ตรวจ git remote -v ว่าชี้ repo ที่ถูกต้อง ไม่ต้องลบหรือ force push

หลัง push เปิดหน้า Code บน GitHub ต้องเห็น run.py และ .github/workflows อยู่ที่ root ห้ามมี Water_Fondue ซ้อนอีกชั้นเหนือ run.py เพราะคำสั่งใน workflow จะหาไฟล์ไม่เจอ

Actions > Offline tests ควรผ่านเป็นสีเขียว หาก GitHub ขอ Enable Actions ให้เปิดก่อน แล้วรัน Offline tests ผ่าน workflow_dispatch ได้


## 7 ตั้งค่ารหัสและเปิด Pages

ที่ repository water-fondue ไป Settings > Secrets and variables > Actions

1. ในแท็บ Secrets กด New repository secret ตั้ง Name เป็น SUPABASE_URL วาง Project URL แล้ว Save
2. สร้างอีก Secret ชื่อ SUPABASE_SECRET_KEY วางค่า sb_secret_ ที่ได้จาก Supabase แล้ว Save
3. ไปแท็บ Variables > New repository variable สร้าง RUN_ENABLED ค่า false
4. สร้าง SEND_LINE ค่า false เพื่อปิดโมดูล LINE ไว้ ชุดเริ่มต้นไม่ต้องมี LINE token
5. ไป Settings > Pages > Build and deployment > Source เลือก GitHub Actions

| ประเภท | ชื่อที่ต้องตรง | ตัวอย่างหรือที่มา |
|---|---|---|
| Secret | SUPABASE_URL | https://PROJECT_REF.supabase.co |
| Secret | SUPABASE_SECRET_KEY | backend secret จาก Supabase |
| Variable | RUN_ENABLED | false ระหว่างติดตั้ง |
| Variable | SEND_LINE | false ในชุดเริ่มต้น |

Secrets จะถูกส่งให้ Python ตอนรัน job เท่านั้น ไม่เขียนลง site/app.js หรือ config.json หลัง Save จะเปิดอ่านค่า secret เดิมไม่ได้ หากใส่ผิดให้ Update secret

## 8 รัน Cloud ครั้งแรกและเปิดเว็บ

1. ไป Actions > Collect and publish > Run workflow เลือก branch main แล้วกด Run workflow
2. เปิดรายการรันล่าสุด รอ collect และ publish เป็นสีเขียว งานแรกอาจต้องรอ Pages environment
3. ถ้า collect ล้มเหลว เปิด step Collect water level อ่าน status code แล้วดูหัวข้อแก้ปัญหา
4. กลับ Supabase > Table Editor ตรวจ stations และ observations ต้องมีข้อมูล พร้อม state key last_success
5. กลับ Settings > Pages เปิด URL ที่ GitHub แสดง โดยทั่วไปคือ https://YOUR_USERNAME.github.io/water-fondue/
6. เปรียบเทียบชื่อสถานี ระดับน้ำ และเวลาวัดกับ https://sukhothai.thaiwater.net/wl

ผลลัพธ์ที่ต้องได้คือเว็บเปิดจากมือถือได้โดยไม่ต้องเปิด VS Code หรือ local server ถ้าเว็บแสดงข้อมูลเก่า ให้ดูเวลาวัดแยกจากเวลาดึงสำเร็จ อย่าแปลข้อความความสดว่าเป็นสถานะปลอดภัยจากน้ำท่วม


## 9 เปิดให้รันอัตโนมัติ

เมื่อ manual run ผ่าน ไป Variables เปลี่ยน RUN_ENABLED เป็น true ตาราง collect ตั้งเป็นนาที 7, 22, 37 และ 52 ของทุกชั่วโมงในเวลา UTC ระยะห่างเป้าหมาย 15 นาที

```yaml
schedule:
  - cron: '7,22,37,52 * * * *'
```

รอดู Actions อย่างน้อยสองรอบ scheduled run จากนั้นตรวจว่า state.last_success เปลี่ยนและเว็บอัปเดต เวลาวัดบางสถานีอาจไม่เปลี่ยนเพราะต้นทางยังส่งค่าเดิม

ถ้าต้องการทุก 10 นาที เปลี่ยน cron ใน .github/workflows/collect.yml เป็นค่าด้านล่าง แล้ว commit และ push จะเพิ่มจำนวนรันและ raw storage ประมาณ 50 เปอร์เซ็นต์เมื่อเทียบกับ 15 นาที

```yaml
  - cron: '7,17,27,37,47,57 * * * *'
```

GitHub schedule เป็น best effort อาจล่าช้าหรือบางรอบไม่ทำงานเมื่อโหลดสูง และ public repository ที่ไม่มี activity 60 วันอาจถูกปิด schedule ให้ผู้ดูแลตรวจ Actions และเปิดใช้งานใหม่ตามที่หน้าจอแสดง ไม่ใช่บริการที่รับประกันเวลาเตือนภัย

หยุดงานตามเวลาโดยตั้ง RUN_ENABLED=false ทั้ง collect และ cleanup จะหยุดตาม schedule แต่กด manual Run workflow ยังทำงานได้ เวลาบำรุงรักษาให้รอ workflow ที่กำลังทำอยู่จบก่อน

## 10 เก็บ raw และดูพื้นที่

raw_days ใน config.json กำหนด 7 หรือ 15 วัน ค่าเริ่มต้น 7 วัน โค้ดเก็บ JSON ต้นทางเฉพาะจังหวัดที่เลือก บีบอัดเป็น .json.gz และใช้ชื่อ wf2_DATE_HASH.json.gz ข้อมูลเหมือนกันในวัน UTC เดียวกันจะใช้ชื่อเดิม

workflow Clean expired raw ตั้งวันละครั้ง 17:20 UTC หรือ 00:20 ไทยของวันถัดไป ลบเฉพาะ raw ที่เข้าเงื่อนไขอายุ ไม่ลบ observations หาก scheduler ช้า การลบก็ช้าตาม

ไป Actions > Clean expired raw > Run workflow ทดสอบได้หลัง bucket พร้อม ตรวจ Storage ว่าไฟล์ใหม่ยังอยู่ และหมั่นดู Usage ของ Supabase หากใกล้เต็มให้สำรองและวางแผน archive ก่อน ไม่เปิดทุกจังหวัดทันที

ตัวอย่างประมาณจำนวน history ที่เพิ่มสูงสุดถ้าทุกสถานีมีเวลาใหม่ทุกครั้ง: 18 สถานี × 96 รอบต่อวัน = 1,728 แถวต่อวัน หรือ 51,840 แถวใน 30 วัน จำนวนจริงมักต่างออกไปเพราะ upsert ค่าเวลาเดิม ขนาด MB ต้องวัดรวม index ด้วย ไม่คำนวณจากจำนวนแถวอย่างเดียว


## 11 ฐานข้อมูลเก็บอะไรและป้องกันซ้ำอย่างไร

| วัตถุ | หน้าที่ | คีย์และตัวอย่าง |
|---|---|---|
| stations | ชื่อและพื้นที่ของสถานี | station_key เช่น thaiwater:waterlevel:9:645 |
| observations | ประวัติค่าตรวจวัด | station_key ร่วมกับ observed_at |
| state | เวลาดึงสำเร็จและสถานะงานภายใน | key เช่น last_success |
| latest_water | view ค่าล่าสุดรายสถานี | อ่านจากสองตารางแรก |
| water-raw | bucket ส่วนตัวเก็บ JSON gzip | ชื่อไฟล์ตามวัน UTC และ hash |
| site/data.json | snapshot สาธารณะสำหรับเว็บ | ค่าล่าสุดและเวลาดึงสำเร็จ |

| คอลัมน์หลัก | ความหมาย | แหล่งข้อมูลหรือกติกา |
|---|---|---|
| station_key | รหัสสถานีแบบไม่ชนหน่วยงาน | agency.id + station.id ไม่ใช้ id ของ record |
| name | ชื่อสถานี | tele_station_name แล้วจึง fallback ชื่อรูปแบบอื่น |
| province_code | รหัสจังหวัด | geocode.province_code เช่น 64 |
| district_code | รหัสอำเภอ 4 หลัก | จังหวัด 2 หลักต่อกับ amphoe_code 2 หลัก |
| observed_at | เวลาเซนเซอร์วัด | waterlevel_datetime แปลงจากเวลาไทยเป็น UTC |
| level_msl | ระดับน้ำ ม.รทก. | waterlevel_msl ไม่แทน missing ด้วย 0 |
| level_m | ระดับน้ำหน่วยเมตรตามต้นทาง | waterlevel_m ไม่ถือว่าเป็น datum เดียวกับ MSL |
| situation | รหัสสถานะต้นทาง | situation_level เก็บไว้โดยไม่แปลเป็นเกณฑ์ของเรา |

ตัวอย่าง หากดึงสถานีเดิมเวลา 12:00 ซ้ำสามครั้ง จะมีหนึ่งแถวสำหรับเวลา 12:00 ถ้าต้นทางแก้ค่าของเวลาเดิม ระบบ update แถวนั้น เมื่อเวลาวัดเปลี่ยนเป็น 13:00 จึงเพิ่มอีกแถว ระบบนี้ไม่เก็บ revision audit ของค่าที่ถูกแก้ทับ

ค่าล่าสุดต่อสถานีมาจากเวลาวัดสูงสุด ไม่ใช่เวลาที่เปิดเว็บ ข้อมูลที่เวลาผิดไปในอนาคตยังเก็บตามต้นทาง แต่เว็บจะทำเครื่องหมายผิดปกติเมื่อเกิน max_future_minutes หาก timestamp ผิดมากต้องตรวจและแก้ข้อมูลต้นทางก่อนถือเป็นค่าล่าสุดที่เชื่อถือได้


## 12 สำรองและทดลองกู้คืน

Supabase Free ไม่มี automatic backup รวมในแพ็กเกจ คู่มือนี้ใช้คำสั่ง backup ดึง stations และ observations ลง gzip JSONL เก็บนอก GitHub สาธารณะ ไม่รวม raw และ private alert state

1. ตั้ง RUN_ENABLED=false แล้วรอ collect/cleanup ที่ค้างอยู่จบ ห้ามรัน manual ระหว่าง backup เพื่อให้ข้อมูลไม่เปลี่ยนขณะอ่านหลายหน้า
2. เปิด PowerShell ใน project ตั้ง URL และอ่าน Secret ผ่านช่องกรอกแบบซ่อน ไม่พิมพ์ secret ลงคำสั่งโดยตรง

```powershell
$env:SUPABASE_URL="https://PROJECT_REF.supabase.co"
$secure = Read-Host "Supabase secret" -AsSecureString
$env:SUPABASE_SECRET_KEY = [System.Net.NetworkCredential]::new("", $secure).Password
py -3 run.py backup --profile production --output data/backup/water_backup.jsonl.gz
```

3. สร้างโฟลเดอร์ทดสอบการกู้คืนแยกด้วยการใช้ profile local/test ที่ยังไม่มี DB หาก test DB มีอยู่ให้เปลี่ยนชื่อโฟลเดอร์ data/test เก็บไว้ก่อน อย่าลบทิ้งหากมีข้อมูลที่ต้องใช้
4. รัน restore แล้ว export เพื่อเปิดเว็บตรวจชื่อและค่าที่กู้มา

```powershell
py -3 run.py restore --profile test --input data/backup/water_backup.jsonl.gz
py -3 run.py export --profile test
py -3 -m http.server 8000 --directory site
```

5. เทียบจำนวนแถว stations และ observations ใน SQLite กับ Supabase ตอนหยุดเก็บข้อมูล และตรวจช่วงเวลา min/max ให้ตรง การ restore เป็น upsert ไม่ล้างข้อมูลเดิม จึงควรใช้ DB ทดสอบว่าง
6. คัดลอก gzip ไปที่เก็บสำรองของคุณอีกแห่ง ล้าง environment แล้วเปิด RUN_ENABLED=true

```powershell
Remove-Item Env:SUPABASE_SECRET_KEY
Remove-Item Env:SUPABASE_URL
Remove-Variable secure
```

หลัง restore หน้าเว็บจะติดป้าย test และอาจไม่มีเวลาดึงสำเร็จ เพราะ backup ไม่รวม state เป็นพฤติกรรมปกติ คำสั่ง restore รองรับ local/test เท่านั้น การกู้กลับ Cloud ต้องวางแผนและตรวจข้อมูลเพิ่ม ไม่ได้ทำอัตโนมัติในรุ่นนี้

raw ใช้เพื่อสืบค้นปัญหาต้นทางและถูกลบตามอายุ ส่วน observations เก็บต่อเนื่องจนคุณออกแบบ archive หากต้องการลด DB ห้ามลบก่อนมี backup ที่ทดลองกู้คืนผ่าน


## 13 แก้ปัญหาและตรวจงานก่อนใช้งานจริง

| อาการ | สาเหตุที่ควรตรวจ | วิธีดำเนินการ |
|---|---|---|
| หา run.py ไม่เจอ | เปิดโฟลเดอร์ผิดหรือ repo ซ้อนชั้น | เปิด root ที่มี run.py |
| 0 observations | province หรือ schema เปลี่ยน | ตรวจ config และ raw ไม่เดารหัสสถานี |
| HTTP 401 หรือ 403 | URL กับ Secret ผิด project หรือใช้ public key | Update Secret ไม่เปิดตารางเป็น public |
| RPC 404 | ยังไม่ได้รัน SQL หรือ API schema ไม่พร้อม | ตรวจ ingest_water และ project URL |
| raw upload 404 | ไม่มี bucket หรือสะกดผิด | สร้าง private bucket water-raw |
| Pages 404 | Source ไม่ใช่ Actions หรือ publish ล้มเหลว | ตรวจ Pages settings และ job publish |
| เว็บข้อมูลเก่า | collector ล้มเหลวหรือเซนเซอร์ไม่อัปเดต | เทียบเวลาดึงสำเร็จกับเวลาวัด |
| schedule ไม่รัน | RUN_ENABLED, default branch หรือ inactivity | ตรวจ variable true และ Actions |
| git push ไม่ผ่าน | sign in, URL หรือ repo มี commit เดิม | อ่าน error และตรวจ remote ไม่ force push |
| พื้นที่ DB ใกล้เต็ม | history โตต่อเนื่อง | backup และวางแผน archive ก่อนลบ |

เกณฑ์จบการติดตั้ง

- ทดสอบในเครื่องผ่าน 16 tests และข้อมูลตัวอย่างแยกจาก local
- manual Cloud collect และ publish ผ่านทั้งคู่
- DB มีค่าจริง และรันค่าซ้ำไม่สร้างแถวซ้ำสำหรับ station/time เดิม
- เปิด URL Pages จากมือถือได้และชื่อกับค่าตรงกับ ThaiWater
- scheduled run สำเร็จอย่างน้อยสองรอบ แม้เวลารันอาจคลาดจาก cron
- ทดลอง RUN_ENABLED=false แล้ว schedule หยุดตามคาด และเปิดกลับหลังตรวจ
- รู้วิธีดู Usage, raw cleanup, backup และได้ทดลอง restore ใน DB ว่าง
- ไม่มี Secret Key ในไฟล์ที่ commit หรือใน site/ และ anon อ่าน/เขียนตารางไม่ได้

วิธีอัปเดตโค้ดภายหลัง: แก้ไฟล์ใน VS Code แล้วใช้ git add ., git commit และ git push จากนั้นตรวจ Offline tests และกด Collect and publish ด้วยมือ การ push อย่างเดียวไม่ deploy เว็บใน workflow นี้

LINE เป็นโมดูลเสริมที่คงไว้จากรุ่นเดิมและปิดโดยค่าเริ่มต้น งานเริ่มต้นนี้เสร็จได้โดยไม่สมัคร LINE OA หากจะเปิดแจ้งเตือน ต้องออกแบบเกณฑ์รายสถานีและตรวจโควตาแยก ดู docs/05_LINE_OPTIONAL_TH.md


## 14 โครงสร้างโมดูลและแหล่งอ้างอิง

| ไฟล์หรือโฟลเดอร์ | หน้าที่ |
|---|---|
| run.py | จุดเรียกโปรแกรม |
| config.json | จังหวัด อายุ raw และเกณฑ์ความสด |
| water_fondue/cli.py | จัดลำดับ collect export cleanup backup restore |
| water_fondue/sources/thaiwater.py | ดึง API และคัด raw ของจังหวัด |
| water_fondue/transform.py | แปลงชื่อ เวลา ตัวเลข และสร้างคีย์ |
| water_fondue/storage.py | เขียน SQLite หรือ Supabase ตาม profile |
| water_fondue/raw.py | บีบอัด เก็บ และลบ raw ที่หมดอายุ |
| water_fondue/http.py | timeout และ retry HTTP |
| water_fondue/alerts.py | LINE เสริม ปิดไว้ในชุดเริ่มต้น |
| sql/supabase.sql และ verify.sql | สร้าง DB และตรวจผลแบบอ่านอย่างเดียว |
| .github/workflows | tests เก็บข้อมูล เผยแพร่เว็บ และ cleanup |
| site/ | HTML JavaScript และ snapshot ที่สร้างตอนรัน |
| tests/ | fixture และ tests ไม่ใช้ credential จริง |

เริ่มแก้จากจุดไหน: เปลี่ยนจังหวัดใน config.json; ถ้า API เปลี่ยนชื่อคอลัมน์แก้ transform.py; ถ้าเพิ่มฝนให้สร้าง source adapter แยกและออกแบบตารางฝน อย่าใส่ข้อมูลฝนลง level_msl; ถ้าปรับหน้าเว็บแก้ site/ โดยไม่แตะ key

เอกสารอ้างอิง ตรวจวันที่ 1 ตุลาคม 2026

1. Supabase Free และโควตา: https://supabase.com/pricing
2. Supabase API keys: https://supabase.com/docs/guides/getting-started/api-keys
3. GitHub Actions billing: https://docs.github.com/en/actions/concepts/billing-and-usage
4. GitHub schedule และ inactivity: https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows
5. GitHub Pages ผ่าน Actions: https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages
6. ThaiWater สุโขทัย: https://sukhothai.thaiwater.net/wl
7. Endpoint ที่ตั้งใน config: https://api-v3.thaiwater.net/api/v1/thaiwater30/provinces/waterlevel

เมนูผู้ให้บริการและโควตาอาจเปลี่ยนได้ ให้ยึดเอกสารทางการและหน้าบัญชีที่ใช้อยู่ Endpoint นี้เป็น endpoint ที่ตรวจการตอบกลับได้ในการทดสอบ ไม่ใช่สัญญาว่า schema หรือการเข้าถึงจะคงเดิมตลอดไป
