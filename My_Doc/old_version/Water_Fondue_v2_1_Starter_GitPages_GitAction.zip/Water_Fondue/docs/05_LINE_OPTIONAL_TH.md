# LINE optional module

โมดูลเสริมจากรุ่น 2 ใช้เมื่อเว็บและ DB ผ่านแล้ว ปิดไว้ตามค่าเริ่มต้น ยังไม่ได้ตรวจบริการ LINE สดในชุดงานนี้ ให้ตรวจคู่มือผู้ให้บริการก่อนเปิดใช้งาน


รุ่นนี้รองรับแจ้งผู้ดูแลคนเดียว (user ID ขึ้นต้น U) ไม่รองรับกลุ่ม/ส่งประชาชนจำนวนมาก
1. สร้าง LINE Official Account Free ผ่าน https://manager.line.biz
2. เปิด Messaging API ใน settings ของ OA แล้วไป https://developers.line.biz/console/
3. เปิด channel ของ OA → Messaging API → ออก Channel access token
4. ใช้ user ID ของบัญชีผู้ดูแลที่แสดงใน console เมื่อบัญชีนั้นอยู่ใน provider/channel
   แล้วเพิ่ม OA เป็นเพื่อน ถ้าไม่พบ ID ต้องทำ webhook ตามเอกสาร LINE; ZIP นี้ไม่มี webhook
5. เพิ่ม Secrets `LINE_CHANNEL_ACCESS_TOKEN` และ `LINE_TARGET_ID` ใน GitHub
6. ตรวจโควตา Free จริงใน OA Manager; line_monthly_cap=50 เป็นเพดานที่ตั้งเอง
   ไม่ใช่จำนวนฟรีที่ LINE รับรอง และต้องไม่ตั้งสูงกว่าโควตา Free ของบัญชี
7. ดู station_key ใน SQLite/Supabase แล้วใส่ rules ใน config.json เช่นรูปแบบ:

```json
"rules": {
  "thaiwater:waterlevel:AGENCY_ID:STATION_ID": {"warning_msl": 0}
}
```

เลข 0 ในตัวอย่างไม่ใช่เกณฑ์ใช้งานจริง! ต้องแทนด้วยเกณฑ์ ม.รทก. ของสถานีนั้น
ที่ผู้เชี่ยวชาญอนุมัติ ห้ามนำระดับตลิ่งต่างสถานีหรือหน่วยอื่นมาใช้
8. ทดสอบบน local ด้วยข้อมูลสดและ rule ที่ยืนยัน: จะพิมพ์ LINE preview ไม่ส่งจริง
9. เปิด line_enabled=true ใน config และ Variable SEND_LINE=true เมื่ออนุมัติแล้ว
10. Run workflow ด้วยมือก่อน ตรวจข้อความและ private state แล้วค่อยปล่อย schedule
11. ปิดส่งทันที: SEND_LINE=false; ข้อมูลและเว็บยังทำงาน

เงื่อนไข: ส่งครั้งแรกเมื่อ warning, ส่ง recovery หลัง warning กลับ normal,
ไม่ส่งสถานะเดิมซ้ำ และไม่ส่งเมื่อข้อมูลเก่า/future/null ไม่มี cooldown เพิ่มในรุ่นนี้
ถ้าค่าสลับขึ้นลงบ่อย quota อาจหมดเร็ว ควรยืนยัน rule/hysteresis ก่อนขยายผู้รับ
ถ้า pending LINE ค้างหรือเกิน 23h ให้ปิดส่ง ตรวจ OA และ state ก่อนแก้ state ด้วยมือ
อย่าลบ pending เพื่อ retry แบบเดาสุ่ม อาจส่งซ้ำ

