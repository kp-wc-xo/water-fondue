เริ่มอ่าน README.md และ docs/01_SETUP_TH.md
Water Fondue 2.1 — Python 3.11+
